#ifndef TIMEDELAY_H
#define TIMDELAY_H
#include <xc.h>

void delay_ms(uint16_t time_ms);

#endif