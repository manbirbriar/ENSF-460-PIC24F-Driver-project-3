#ifndef IOS_H
#define IOS_H
#include <xc.h>

void IOinit(void);
void IOcheck(void);

#endif